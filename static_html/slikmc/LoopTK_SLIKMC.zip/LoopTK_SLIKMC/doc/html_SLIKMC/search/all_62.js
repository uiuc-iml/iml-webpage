var searchData=
[
  ['bfactor',['BFactor',['../classBFactor.html',1,'BFactor'],['../classBFactor.html#a91f2c9fcac4abc6be3374ef211567763',1,'BFactor::BFactor()']]],
  ['binarysearch',['BinarySearch',['../classBinarySearch.html',1,'']]]
];
