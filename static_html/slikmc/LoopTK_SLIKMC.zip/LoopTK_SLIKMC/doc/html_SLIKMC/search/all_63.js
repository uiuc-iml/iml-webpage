var searchData=
[
  ['chidistribution',['ChiDistribution',['../classChiDistribution.html',1,'']]],
  ['compareprotein_5fscore',['CompareProtein_Score',['../classCompareProtein__Score.html',1,'']]],
  ['construct',['construct',['../classRamachandranPlot.html#a742cd67cdd45fdeae7003958114b1502',1,'RamachandranPlot']]]
];
