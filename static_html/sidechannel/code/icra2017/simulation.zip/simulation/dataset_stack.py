
from __future__ import division
import numpy as np
import os, sys, theano, traceback
import theano.tensor as T
import matplotlib.pyplot as plt

class DataFeeder:
	def __init__(self, init_idx=1, test_idx=0):
		self.init_idx = init_idx
		self.cur_idx = init_idx
		self.test_idx = test_idx

	def next_training_set_shared(self):
		try:
			data = np.load('data/data_%i.npz'%self.cur_idx)
		except IOError:
			traceback.print_exc()
			print 'done all chunk files at %i'%self.cur_idx
			self.cur_idx = self.init_idx
		data = np.load('data/data_%i.npz'%self.cur_idx)
		X = data['X'].astype(theano.config.floatX)
		y = data['y'].astype('int32')
		X_loc = X[:, 0:4]
		X_occ = X[:, 4:10004]
		X = np.hstack((X_occ, X_loc.repeat(10000, axis=1)))
		X_shared = theano.shared(X, borrow=True)
		y_shared = theano.shared(y, borrow=True)
		self.cur_idx += 1
		return X_shared, y_shared
	
	def next_training_set_raw(self):
		try:
			data = np.load('data/data_%i.npz'%self.cur_idx)
		except IOError:
			traceback.print_exc()
			print 'done all chunk files at %i'%self.cur_idx
			self.cur_idx = self.init_idx
		if self.cur_idx%100==0:
			print 'using training file %i'%self.cur_idx
		data = np.load('data/data_%i.npz'%self.cur_idx)
		X = data['X'].astype(theano.config.floatX)
		y = data['y'].astype('int32')
		X_loc = X[:, 0:4]
		X_occ = X[:, 4:10004]
		X = np.hstack((X_occ, X_loc.repeat(10000, axis=1)))
		self.cur_idx += 1
		return X, y
	
	def test_set_shared(self):
		data = np.load('data/data_%i.npz'%self.test_idx)
		X = data['X'].astype(theano.config.floatX)
		y = data['y'].astype('int32')
		X_loc = X[:, 0:4]
		X_occ = X[:, 4:10004]
		X = np.hstack((X_occ, X_loc.repeat(10000, axis=1)))
		X_occ_shared = theano.shared(X, borrow=True)
		y_shared = theano.shared(y, borrow=True)
		return X_occ_shared, y_shared
