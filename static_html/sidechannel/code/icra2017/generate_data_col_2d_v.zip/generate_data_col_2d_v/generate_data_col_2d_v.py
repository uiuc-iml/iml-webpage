
from __future__ import division

import numpy as np
from environment import Environment
import klampt.vectorops as vops
import matplotlib.pyplot as plt
import random, time
from itertools import cycle
from scipy import stats
from multiprocessing import Pool

'''
data format: 
pt_x, pt_y, speed_x, speed_y, occ_grid (10000 entries), collision_time, valid_flag
pt_x and pt_y are random numbers between 0 and 100
speed_x and speed_y are random numbers between 1 and 5 (and negative)
'''

def generate_data(N, e=None, time_no_collision=1000, save_file_name=None):
	final_data = np.zeros((N, 100*100+6), dtype='float32')
	num_generated = 0
	if e is None:
		e = Environment()
		# e.num_obstacles = 20
	env_data = e.gen_stream_data(0.1, num_frames=N)
	while num_generated != N:
		for i in xrange(N - num_generated):
			environment = env_data[:,:,i]
			while True:
				pt_x = random.random()*100
				pt_y = random.random()*100
				if environment[int(pt_x), int(pt_y)]==0: # free start point
					break
			speed_x = random.random()*4+1
			speed_y = random.random()*4+1
			# flip the sign randomly
			speed_x *= random.choice([1,-1])
			speed_y *= random.choice([1,-1])
			dir_x, dir_y = vops.unit([speed_x, speed_y])
			cur_pt_x = pt_x
			cur_pt_y = pt_y
			free_flag = 1
			while True:
				cur_pt_x += 0.01*dir_x
				cur_pt_y += 0.01*dir_y
				if int(cur_pt_x)<0 or int(cur_pt_y)<0 or int(cur_pt_x)>=100 or int(cur_pt_y)>=100:
					free_flag = 0 # free path
					break
				if environment[int(cur_pt_x), int(cur_pt_y)]==1:
					break
			if free_flag==0:
				continue
			else:
				collision_dist = vops.distance([cur_pt_x, cur_pt_y], [pt_x, pt_y])
				speed = vops.norm([speed_x, speed_y])
				collision_time = collision_dist / speed
			final_data[num_generated, 0:4] = [pt_x, pt_y, speed_x, speed_y]
			final_data[num_generated, 4:10004] = environment.flatten()
			final_data[num_generated, 10004] = collision_time
			final_data[num_generated, 10005] = free_flag
			num_generated += 1
		# print 'looped %i'%num_generated
	if save_file_name is not None:
		np.savez_compressed(save_file_name, Xy=final_data)
		print 'done'
	else:
		return final_data

def save_func(name):
	generate_data(10000, save_file_name=name)

if __name__ == '__main__':
	i = 0
	while True:
		save_func('data/%i.npz'%i)
		i += 1
