This zip file generates data for Col 2D V Problem. 
Folder structure has been set up correctly. 
Running generate_data_col_2d_v.py will generate data chunk file in "data" folder. 
Each data chunk file contains 10000 problem instances. 
Running environment.py will show an animation of the problem environment. 
For questions, please email yilun@cs.duke.edu. 
