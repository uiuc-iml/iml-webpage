
from __future__ import division

import numpy as np
import klampt.vectorops as vops
import random, time, cv2

class Obstacle:
	def __init__(self, radius, speed, pos, dir):
		self.radius = radius
		self.speed = speed
		self.pos = pos
		self.dir = vops.unit(dir)
		bitmap = [(i,j) for i in xrange(-int(radius)-1, int(radius)+2) for j in xrange(-int(radius)-1, int(radius)+2)]
		self.bitmap = np.array(filter(lambda p:vops.norm(p)<=radius, bitmap))

	def run(self, t=0.1):
		self.pos = vops.add(self.pos, vops.mul(self.dir, self.speed*t))

class Environment:
	def __init__(self):
		self.width = 100
		self.height = 100
		self.num_obstacles = 5
		self.obstacle_radius_min = 6
		self.obstacle_radius_max = 10
		self.obstacle_speed_min = 5
		self.obstacle_speed_max = 20
		self.obss = [self.create_random_obstacle() for _ in xrange(self.num_obstacles)]

	def create_random_obstacle(self):
		pos = [random.uniform(10, self.height-10), random.uniform(10, self.width-10)]
		radius = random.uniform(self.obstacle_radius_min, self.obstacle_radius_max)
		speed = random.uniform(self.obstacle_speed_min, self.obstacle_speed_max)
		dir = [random.random()-0.5, random.random()-0.5]
		return Obstacle(radius, speed, pos, dir)

	def run(self, t=0.1):
		map(lambda obs:obs.run(t), self.obss)
		for obs in self.obss[:]:
			x, y = obs.pos
			if not (-10<=x<=self.height+10 and -10<=y<=self.width+10):
				self.obss.remove(obs)
		num_refill = self.num_obstacles - len(self.obss)
		for i in xrange(num_refill):
			self.obss.append(self.create_random_obstacle())

	def get_occ_grid(self):
		grid = np.zeros((self.height, self.width))
		for o in self.obss:
			bitmap = o.bitmap + o.pos
			bitmap = bitmap[np.logical_and.reduce([0<=bitmap[:,0], bitmap[:,0]<self.height, 0<=bitmap[:,1], bitmap[:,1]<self.width])]
			bitmap = bitmap.astype('int32')
			grid[bitmap[:,0], bitmap[:,1]] = 1
		return grid

	def gen_stream_data(self, time_increment, total_time=None, num_frames=None):
		if num_frames is None:
			num_frames = int(total_time/time_increment)
		data = np.zeros((self.height, self.width, num_frames))
		for i in xrange(num_frames):
			data[:,:,i] = self.get_occ_grid()
			self.run(time_increment)
		return data

if __name__ == '__main__':
	cv2.namedWindow('Environment')
	e = Environment()
	while True:
		e.run(0.1)
		grid = e.get_occ_grid()
		cv2.imshow('Environment', (grid*255).astype(np.uint8))
		cv2.waitKey(5)