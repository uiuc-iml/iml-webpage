
import subprocess
start_idx = 0
total_num = 60
for i in xrange(100000):
	print "loop..."
	subprocess.call(['python', 'write_data.py', str(start_idx), str(total_num)])
	start_idx += total_num
