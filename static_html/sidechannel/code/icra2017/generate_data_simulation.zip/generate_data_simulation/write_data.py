
from __future__ import division
import numpy as np
import sys, random, os
import random_environment as rand_env
from multiprocessing import Pool
import traceback

def write_batch(idx, num=1000):
	print 'started generating data/data_%i.npz'%idx
	batch_data = dict()
	X = np.zeros((num, 10004), dtype='float32')
	y = np.zeros(num, dtype='int32')
	i = 0
	while i<num:
		try:
			x_start = random.random()*rand_env.HEIGHT
			y_start = random.random()*rand_env.WIDTH
			x_goal = random.random()*rand_env.HEIGHT
			y_goal = random.random()*rand_env.WIDTH
			all_pts = rand_env.make_random_environment(num_triangles=45, avoid_pts=[[x_start, y_start], [x_goal, y_goal]])
			occupancy = rand_env.make_occupancy_grid_two_level(all_pts, rand_env.WIDTH, rand_env.HEIGHT, 30, 30)
			collide_sim = rand_env.collide_simulation(all_pts, p1=(x_start, y_start), p2=(x_goal, y_goal))
			X[i, :4] = [x_start, y_start, x_goal, y_goal]
			X[i, 4:] = occupancy.flatten()
			y[i] = collide_sim[0]
		except:
			print "error occurred"
			traceback.print_exc()
			continue
		i += 1
	np.savez_compressed('data/data_%i.npz'%idx, X=X, y=y)

if __name__ == '__main__':
	start_idx = int(sys.argv[1])
	total_num = int(sys.argv[2])
	p = Pool()
	p.map(write_batch, [i+start_idx for i in xrange(total_num)])
