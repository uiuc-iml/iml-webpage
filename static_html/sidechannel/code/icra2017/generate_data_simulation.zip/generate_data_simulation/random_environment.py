
from __future__ import division
import matplotlib.pyplot as plt
import numpy as np
import random, time, inspect
from math import sin, cos, pi
from shapely.geometry import Polygon, LineString, LinearRing, Point
from shapely.ops import cascaded_union
from itertools import tee, izip

amin = min # back-up for min since it will be polluted by wildcard import
amax = max # back-up for max since it will be polluted by wildcard import
aabs = abs # back-up for abs since it will be polluted by wildcard import
arandom = random # the random module
from Box2D.b2 import * # This maps Box2D.b2Vec2 to vec2 (and so on)

WIDTH = 100
HEIGHT = 100
TRIANGLE_RADIUS_MEAN = 6
TRIANGLE_RADIUS_STDEV = 3

TARGET_FPS=60
TIME_STEP=1.0/TARGET_FPS

def pairwise(iterable):
	"s -> (s0,s1), (s1,s2), (s2, s3), ..."
	a, b = tee(iterable)
	next(b, None)
	return izip(a, b)

def make_random_triangle(avoid_pts=None):
	while True:
		center_x, center_y = arandom.random()*WIDTH, arandom.random()*HEIGHT
		pts = []
		for _ in xrange(3):
			rand_angle = arandom.random()*2*pi
			rand_radius = np.random.normal(TRIANGLE_RADIUS_MEAN, TRIANGLE_RADIUS_STDEV)
			x = center_x + cos(rand_angle) * rand_radius
			y = center_y + sin(rand_angle) * rand_radius
			pts.append((x,y))
		if not LinearRing(pts).is_ccw:
			pts = pts[::-1]
		if avoid_pts is None:
			break
		triangle = Polygon(pts)
		containing = [triangle.intersects(Point(pt)) for pt in avoid_pts]
		if sum(containing)==0:
			break
	return pts

def make_random_environment(num_triangles=20, avoid_pts=None):
	return [make_random_triangle(avoid_pts) for _ in xrange(num_triangles)]

def make_occupancy_grid(all_pts, width, height):
	all_polygons = []
	for pts in all_pts:
		all_polygons.append(Polygon(pts))
	unioned = cascaded_union(all_polygons)
	occupancy = np.zeros((width, height))
	for i in xrange(height):
		for j in xrange(width):
			pixel_grid = Polygon([(j,i), (j+1, i), (j+1, i+1), (j, i+1)])
			occupancy[i,j] = unioned.intersection(pixel_grid).area
	occupancy = occupancy[::-1,:]
	return occupancy

def make_occupancy_grid_two_level(all_pts, width, height, cell_num_h=3, cell_num_w=3):
	cell_bdy_h = map(int, np.linspace(0, height, cell_num_h+1)) # cell boundary
	cell_bdy_w = map(int, np.linspace(0, width, cell_num_w+1))
	belonging = dict() # belonging[h][w] is a list of polygons intersecting with (w,h)-th large cell
	macro_pixels = dict()
	for i in xrange(cell_num_h):
		belonging[i] = dict()
		macro_pixels[i] = dict()
		for j in xrange(cell_num_w):
			belonging[i][j] = list()
			macro_pixels[i][j] = Polygon([(cell_bdy_w[j], cell_bdy_h[i]), 
				(cell_bdy_w[j+1], cell_bdy_h[i]), (cell_bdy_w[j+1], cell_bdy_h[i+1]), (cell_bdy_w[j], cell_bdy_h[i+1])])
	
	for pts in all_pts:
		poly = Polygon(pts)
		for i in xrange(cell_num_h):
			for j in xrange(cell_num_w):
				poly_macro_pixel = macro_pixels[i][j]
				if poly.intersects(poly_macro_pixel):
					belonging[i][j].append(poly)

	for i in xrange(cell_num_h):
		for j in xrange(cell_num_w):
			if len(belonging[i][j])!=0:
				belonging[i][j] = cascaded_union(belonging[i][j])
			else:
				belonging[i][j] = None

	occupancy = np.zeros((height, width))
	for h_idx, h_interval in enumerate(pairwise(cell_bdy_h)):
		h_cur, h_next = h_interval
		for w_idx, w_interval in enumerate(pairwise(cell_bdy_w)):
			w_cur, w_next = w_interval
			if belonging[h_idx][w_idx] is None:
				continue
			for i in xrange(h_cur, h_next):
				for j in xrange(w_cur, w_next):
					pixel_grid = Polygon([(j,i), (j+1, i), (j+1, i+1), (j, i+1)])
					occupancy[i,j] = belonging[h_idx][w_idx].intersection(pixel_grid).area
	occupancy = occupancy[::-1,:]
	return occupancy

def make_world(all_pts):
	w = world(gravity=(0,0),doSleep=True)
	for pts in all_pts:
		w.CreateStaticBody(shapes=polygonShape(vertices=pts))
	return w

def dist(pos1, pos2):
	return ((pos1[0]-pos2[0])**2+(pos1[1]-pos2[1])**2)**0.5

def simulate(world, start, end, radius=0.1, density=1):
	path = []
	path.append(start)
	body = world.CreateDynamicBody(position=[i for i in start])
	body.CreateCircleFixture(radius=radius, density=density, friction=0)
	prev_pos = None
	ite = 0
	while True:
		ite += 1
		if ite>10000:
			return list(body.position), path
		dir_x = end[0]-body.position[0]
		dir_y = end[1]-body.position[1]
		magnitude = (dir_x**2+dir_y**2)**0.5
		if magnitude<1e-10:
			velocity = [dir_x*5, dir_y*5]
		else:
			velocity = [amin([dir_x*5/magnitude, dir_x*5]), amin([dir_y*5/magnitude, dir_y*5])]
		body.__SetLinearVelocity(velocity)
		world.Step(TIME_STEP, 10, 10)
		path.append([i for i in body.position])
		if (prev_pos is not None) and (dist(prev_pos, body.position)<1e-5):
			break
		prev_pos = [i for i in body.position]
	pos = list(body.position)
	world.DestroyBody(body)
	return pos, path

def collide_simulation(all_pts, p1=(10,10), p2=(90,90)): # 1 is colliding, 0 is free
	world = make_world(all_pts)
	p, path = simulate(world, p1, p2)
	return dist(p, p2) > 1e-3, path

def draw_environment(all_pts):
	plt.hold(True)
	for pts in all_pts:
		plt.fill([x for x,_ in pts], [y for _,y in pts])
	plt.axis([0,WIDTH,0,HEIGHT])

if __name__ == '__main__':
	import random
	start = [random.random()*100, random.random()*100]
	end = [random.random()*100, random.random()*100]
	all_pts = make_random_environment(num_triangles=45, avoid_pts=[start, end])
	_, path = collide_simulation(all_pts, start, end)

	occupancy = make_occupancy_grid_two_level(all_pts, WIDTH, HEIGHT, 30, 30)
	plt.figure()

	plt.imshow(1-occupancy, interpolation='none', cmap='Greys_r')
	plt.hold(True)
	xs, ys = map(np.array, zip(*path))
	plt.plot(xs, 100-ys, 'r', linewidth=3)
	plt.plot(start[0], 100-start[1], 'ro')
	plt.plot(end[0], 100-end[1], 'ro')
	plt.axis([0,100,0,100])
	plt.savefig('sim_env.png', bbox_inches='tight')
	plt.show()
