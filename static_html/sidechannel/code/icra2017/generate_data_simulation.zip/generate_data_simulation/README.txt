This zip file generates data for Simulation problem. 
It will write data chunk file into "data" folder. 
Each data chunk file will contain 1000 instances. 
Running data_generation_supervisor.py will start the process. 
This script requires PyBox2D and Shapely packages. 
There is a memory leak issue associated with Box2D. 
Thus, subprocess is used to restart generation automatically. 
If memory issue becomes a problem, decreasing "total_num" in data_generation_supervisor.py will help. 
Running random_environment.py will show a visualization of a simulation problem. 
