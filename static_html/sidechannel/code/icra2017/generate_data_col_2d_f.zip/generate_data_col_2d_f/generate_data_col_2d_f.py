
from __future__ import division

import numpy as np
from environment import Environment
import klampt.vectorops as vops
import matplotlib.pyplot as plt
import random
from itertools import cycle
from scipy import stats
from multiprocessing import Pool

if __name__ == '__main__':
	path = [(80,20), (40,85), (5,70), (20,20), (90,90)]
	speed = [10, 10, 10, 10, 10] # the speed from current waypoint to next waypoint
	dist_segment = []

	total_dist = 0

	# rasterize path
	points_on_path = []
	speeds_on_path = []
	path_wrap_beginning = path + [path[0]]
	for i in xrange(len(path_wrap_beginning)-1):
		for u in np.linspace(0,1,200):
			pt = map(int, vops.interpolate(path_wrap_beginning[i], path_wrap_beginning[i+1], u))
			if len(points_on_path)==0 or (points_on_path[-1]!=pt and (pt not in points_on_path)):
				points_on_path.append(pt)
				sp = vops.mul(vops.unit(vops.sub(path_wrap_beginning[i+1], path_wrap_beginning[i])), speed[i])
				speeds_on_path.append(sp)
		dist_segment.append(vops.distance(path_wrap_beginning[i], path_wrap_beginning[i+1]))
		total_dist += vops.distance(path_wrap_beginning[i], path_wrap_beginning[i+1])
	dist_segment = vops.div(dist_segment, sum(dist_segment))
	segment_sampler = stats.rv_discrete( name='custm', values=( range(len(path)), dist_segment ) )

def uniform_sampler():
	seg_idx = segment_sampler.rvs(size=1)[0]
	return vops.interpolate(path_wrap_beginning[seg_idx], path_wrap_beginning[seg_idx+1], random.random()), seg_idx

def calculate_collision_distance(environment, pt, start_seg_idx):
	if environment[int(pt[0]), int(pt[1])]==1:
		return 0
	cur_seg_idx = start_seg_idx
	cur_start_pt = pt
	cur_end_pt = path_wrap_beginning[cur_seg_idx+1]
	cur_total_dist = 0
	while True:
		for u in np.linspace(0,1,200):
			pt = vops.interpolate(cur_start_pt, cur_end_pt, u)
			if environment[int(pt[0]), int(pt[1])]==1:
				# print 'colliding at (%.2f, %.2f)'%(pt[0], pt[1])
				return cur_total_dist + vops.distance(cur_start_pt, pt)
		cur_total_dist += vops.distance(cur_start_pt, cur_end_pt)
		cur_seg_idx += 1
		if cur_seg_idx==len(path):
			cur_seg_idx = 0
		cur_start_pt = path_wrap_beginning[cur_seg_idx]
		cur_end_pt = path_wrap_beginning[cur_seg_idx+1]
		if cur_total_dist > total_dist + 1: # some error
			return None # not colliding

def generate_data(N, e=None, time_no_collision=1000, save_file_name=None):
	final_data = np.zeros((N, 100*100+4), dtype='float32') # 2 for starting location, 100*100 for environment, 1 for time to collision, 1 for colliding or not (colliding at some point is 1)
	num_generated = 0
	if e is None:
		e = Environment()
	while num_generated!=N:
		env_data = e.gen_stream_data(0.1, num_frames=N-num_generated)
		for i in xrange(N - num_generated):
			pt, start_seg_idx = uniform_sampler()
			environment = env_data[:,:,i]
			if environment[int(pt[0]), int(pt[1])]==1:
				continue
			dist = calculate_collision_distance(environment, pt, start_seg_idx)
			if dist is None:
				free_flag = 0 # 0 if IS free, 1 if not (only those with 1 are valid data)
				dist = time_no_collision
			else:
				free_flag = 1
			final_data[num_generated, 0:2] = pt
			final_data[num_generated, 2:10002] = environment.flatten()
			final_data[num_generated, 10002] = dist
			final_data[num_generated, 10003] = free_flag
			num_generated += 1
		# print 'looped %i'%num_generated
	if save_file_name is not None:
		np.savez_compressed(save_file_name, Xy=final_data)
		print 'done'
	else:
		return final_data


def save_func(name):
	generate_data(10000, save_file_name=name)

if __name__ == '__main__':
	i = 0
	while True:
		save_func('data/%i.npz'%i)
		i += 1