/**
 * This code simply starts up a socket server at the desired port number. The
 * socket server listens for scenario commands at that number, and terminates
 * when the scenario is complete.
 */

#include <iostream>
#include <PVTP/SocketInterface.hpp>

// the scenario API, including I/O is contained in the SCIMP_Scenario namespace
using namespace SCIMP_Scenario;

// the namespace of the socket interface
using namespace SocketInterface;

int main( int argc, char *argv[] ) {
	
	// specify a port number, either the default, or from command line
	int portno;
	if ( argc > 1 ) {
		portno = atoi( argv[1] );
	} else {
		std::cout << "Usage: " << argv[0] << " PORT" << std::endl;
		return 1;
	}

	// start the socket server
	if ( createServer(portno) ) {
		std::cout << "Socket server completed successfully." << std::endl;
	} else {
		std::cout << "Socket server failed." << std::endl;
	}
	
	return 0;	
}
