function [ ] = drawTrajectorySegment( s1, s2, color )
%drawTrajectorySegment Draw a leg of a trajectory to the current figure
%   Draw a leg of a trajectory to the current figure

    % Start point
    x1 = getStateCoord(s1, 'x');
    t1 = getStateCoord(s1, 't');
    v1 = getStateCoord(s1, 'v');
    
    % End point
    t2 = getStateCoord(s2, 't');
    v2 = getStateCoord(s2, 'v');
    
    delta_t = t2 - t1;
    delta_v = v2 - v1;

    a = delta_v / delta_t;
    
    inc = delta_t / 100;
    start = 0;
    stop = delta_t;

    t_test = start:inc:stop;
    x_test = motion(x1, v1, t_test, a);

    if strcmp(color, 'm')
        plot(x_test, t_test+t1, ['-', color], 'LineWidth', 2);
    else
        plot(x_test, t_test+t1, ['-', color]);
    end

end

