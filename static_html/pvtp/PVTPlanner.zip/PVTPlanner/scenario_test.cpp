/**
 * TRUNK
 *
 * EXAMPLE SCENARIO CREATION AND EVALUATION
 *
 * This file demonstrates setting up a simple lane-crossing scenario, and
 * evaluating that scenario to construct path-time obstacles that can be
 * fed into the planner.
 *
 * LIMITATIONS: The API currently only supports scenarios in which
 * the user-controlled vehicle follows a straight-line path, and obstacle
 * vehicles follow straight-line paths that cross the user-controlled vehicle's
 * path perpendicularly; so, scenarios that have the driver driving straight
 * across lanes of traffic. I am working on extending the scenario to handle
 * elliptical as well as linear paths, and arbitrary angles of intersection.
 *
 * SETUP: A scenario consists of a user-controlled vehicle, and a (possibly
 * empty) set of obstacles (other vehicles). These two things are described by
 * the ScenarioUser and ScenarioObstacle classes, respectively.
 *
 * The ScenarioUser class consists of a Vehicle object and a Path object, which
 * respectively describe the characteristics of the user's vehicle (such as
 * length, width, velocity, position, etc.), and the path that the vehicle
 * follows. Because this is the user-controlled vehicle, it also contains
 * a representation of the scenario (the other vehicles and their paths), and
 * and a SCIMP controller which attempts to prevent the user from executing
 * unsafe controls.
 *
 * The ScenarioObstacle class also contains a Vehicle and a Path. Instead of
 * a SCIMP controller, it contains an actual controller that defines how the
 * vehicle is controlled over time. (In this context, control is limited to
 * longitudinal control: acceleration or deceleration.)
 */

#include <iostream>
#include <PVTP/Planner.hpp>
#include <PVTP/ScenarioUser.hpp>
#include <PVTP/Utilities.hpp>

// the planner is contained in the PVTP namespace
using namespace PVTP;

// the scenario API, including I/O is contained in the SCIMP_Scenario namespace
using namespace SCIMP_Scenario;

int main () {
	
	// I use this for reading out values with enough precision to do debugging;
	// sometimes it's handy to print something out to cerr to see what's
	// going on
	std::cerr.precision(Constants::DEBUGGING_OUTPUT_PRECISION);
	
	/**
	 * First, we'll define the system constraints. These are encapsulated in
	 * a Constraints object and handed off to the system.
	 *
	 * Units are in meters and seconds, where appropriate.
	 */
	double path_length = 30.;
	double time_limit = 10.;
	double minimum_velocity = 0.;
	double maximum_velocity = 50.;
	double minimum_acceleration = -10.;
	double maximum_acceleration = 8;
	
	// if constraint construction fails because of inconsistent constraints, fail out
	try {
		Constraints constraints( path_length,
								time_limit,
								minimum_velocity,
								maximum_velocity,
								minimum_acceleration,
								maximum_acceleration );
		
		/**
		 *	Now we begin scenario construction. There are several tasks here:
		 *
		 *	1. Define scenario obstacles. For each of these:
		 *		1. Define a path
		 *		2. Define a controller
		 *		3. Define a vehicle
		 *
		 *	2. Define the scenario user. For this:
		 *		1. Define a path
		 *		2. Define a vehicle
		 *		3. Add each of the scenario obstacles to the scenario user's
		 *			scenario object (which is constructed during ScenarioUser
		 *			construction)
		 *
		 *	That will complete scenario construction. Below is an example
		 *	construction of a simple scenario.
		 */
		
		//
		// 1. Define scenario obstacles
		//
		
		// To define a path for the obstacle, first define begin and end points.
		// These points define a path that intersects the user's path at the
		// 20 meter mark along the user's path, and begins 15 meters above the
		// user's path, and ends 15 meters below it.
		XY_Point obs_path_begin( 20., 15. );
		XY_Point obs_path_end( 20., -15. );
		
		// Construct the obstacle's path.
		Path obstacle_path( obs_path_begin, obs_path_end );
		
		// Construct obstacle controller. The controls are added as
		// (time, control) pairs, where the controls are acceleration or
		// deceleration, and are assumed constant between sequential times.
		// In principle this allows one to define an arbitrary velocity profile
		// for the vehicle along the path; however, the current implementation
		// of the scenario evaluator only considers the initial control.
		// Future revisions will expand this capability.
		Controller obstacle_controller;
		obstacle_controller.addControl( 0., 0. );
		
		// Construct obstacle vehicle. This is the vehicle that our user's
		// vehicle will have to avoid as it (the user's vehicle) crosses lanes.
		// Here we specify the obstacle vehicle's dimensions and dynamic
		// constraints. It's probably a good idea to put a bit of padding around
		// the dimensions of the vehicle to account for measurement and
		// discretization errors. Again, units are meters or seconds as
		// appropriate. Note that the constraints needn't be the same as those
		// defined by the Constraint object for the system.
		double width = 3.5;
		double length = 5.5;
		minimum_velocity = 0.;
		maximum_velocity = 50.;
		minimum_acceleration = -10.;
		maximum_acceleration = 8.;
		Vehicle obstacle_vehicle( width,
								 length,
								 minimum_velocity,
								 maximum_velocity,
								 minimum_acceleration,
								 maximum_acceleration );
		
		// set an initial velocity for this vehicle
		double obstacle_initial_velocity = 5.;
		obstacle_vehicle.setVelocity( obstacle_initial_velocity );
		
		// With the obstacle vehicle, path, and controller defined, we can now
		// construct the scenario obstacle.
		ScenarioObstacle obstacle( obstacle_vehicle, obstacle_path, obstacle_controller );
		
		//
		// 2. Define scenario user
		//
		
		// As before, define begin and end points for the user's path. These
		// points define a path that begins at the origin (NOTE: the user's path
		// should always begin at the origin), and extends path_length meters
		// in the positive X direction. The user path is assumed to always
		// extend in the positive direction. (This is simply a convention of
		// convenience; any direction can be used by applying the appropriate
		// transforms to the input and output.)
		XY_Point user_begin( 0., 0. );
		XY_Point user_end( path_length, 0. );
		
		// Construct the user's path, as before.
		Path user_path( user_begin, user_end );
		
		// Construct user's vehicle. NOTE: The constraints specified for the
		// user's vehicle *DO* need to match the constraints specified in the
		// Constraints object. This ensures that the evaluations of scenario
		// safety are relavent to this vehicle.
		Vehicle user_vehicle( width,
							 length,
							 constraints.getVMin(),
							 constraints.getVMax(),
							 constraints.getAMin(),
							 constraints.getAMax() );
		
		// set an initial velocity for the user vehicle
		double user_initial_velocity = 0.;
		user_vehicle.setVelocity( user_initial_velocity );
		
		// Construct the scenario user. Similar to the scenario obstacle, the 
		// user takes a vehicle and a path. Unlike the obstacle, however, there
		// is no explicit controller since the vehicle is under user control.
		// There are, however, some additional parameters. First, we specify
		// and minimum and maximum final velocity, which define the range of
		// velocities we'd like to end up in at the end of the scenario (that
		// is, we want the vehicle's final velocity to be contained within that
		// range). Currently the final velocity range is respected as far as
		// the planner looksahead, which means that as the vehicle nears the
		// end of the path, and the remaining distance is less than the lookahead
		// the SCIMP controller ceases to filter controls. This makes it possible
		// to end up in the goal position with a velocity outside that specified.
		// I'm working on repairing this.
		// 
		// We also specify an alpha parameter, which is a safety
		// threshold value. In principle, each time the user sends a control to
		// the vehicle, that control is evaluated, and, if it results is a state
		// where the probability of collision is > 1 - alpha, the SCIMP
		// controller intervenes and attempts to provide a safer control.
		// Currently, however, the planner is deterministic, and this is
		// parameter is not used. Future revisions will employ probabilistic
		// decision making, and this parameter will be important.
		double minimum_final_velocity = 0.;
		double maximum_final_velocity = 5.;
		double alpha = 0.999;
		double time_step = 0.1;
		ScenarioUser user( user_vehicle,
						  user_path,
						  minimum_final_velocity,
						  maximum_final_velocity,
						  time_step,
						  alpha,
						  constraints );
		
		// Add the previously defined scenario obstacle to user's scenario.
		user.getScenario().addObstacle( obstacle );
		
		// When we've added all obstacles, we'll initialize the scenario. This
		// computes path-time obstacles and readies the simulations.
		user.initializeScenario();

		/**
		 *	At this point, the scenario is constructed. Scenario evaluation
		 *	takes the provided scenario and computes path-time obstacles used
		 *	by the planner to evaluate the safety of a given state. We can
		 *	take a look at this information.
		 *
		 *	The ScenarioUser object maintains an internal set of path-time
		 *	obstacles, but we can manually compute the set here and print
		 *	out the results.
		 *
		 *	With the default inputs specified in this file, you should see as
		 *	output:
		 *
		 *		Path-time obstacle set size: 1
		 *		Obstacle:
		 *		(12.75, 3.35, [-Inf, +Inf])
		 *		(21.75, 3.35, (empty))
		 *		(21.75, 1.55, [-Inf, +Inf])
		 *		(12.75, 1.55, (empty))
		 *
		 *	Each line under "Obstacle:" corresponds to an obstacle vertex, where
		 *	the first number is the path coordinate, and the second number is
		 *	the time coordinate. The third member is the set of velocities that
		 *	are geometrically feasible at that point. The two empty sets
		 *	correspond to the lower-left and upper-right vertices of the
		 *	obstacle in path-time space: the upper-right point is unreachable
		 *	without colliding with the obstacle, and the lower-left is
		 *	reachable, but collision is inevitable upon reaching it. Time is
		 *	assumed to be monotonically increasing.
		 *
		 */
		
		std::cout << std::endl << "===OUTPUT FROM EXAMPLE SCENARIO===" << std::endl;
		std::cout << std::endl;
		
		// Construct set for storing path-time obstacles.
		PVT_ObstacleSet pt_obstacles;
		
		// Manually compute path-time obstacles.
		if ( user.getScenario().computePathTimeObstacles( pt_obstacles, constraints ) ) {
			std::cout << "Initial set of path-time obstacles, set size: " << pt_obstacles.obstacles->size() << std::endl;
			std::cout << pt_obstacles << std::endl;
			std::cout << std::endl;
		} else {
			std::cout << "Path-time obstacle construction failed." << std::endl;
			std::cout << std::endl;
		}
		
		/**
		 *	Now we can test executing a scenario. The obstacle vehicle will
		 *	proceed along its path according to the initial velocity and given
		 *	control (in this case 5 m/s and 0 m/s^2, respectively). We'll set
		 *	the user control to be 8 m/s^2 at every time step. Applied blindly,
		 *	this control would result in collision, so, at every time step, the
		 *	current state of the system is evaluated by taking the user's
		 *	and computing the state of the system one time step in advance. If
		 *	that future state is deemed unsafe (which means the planner was
		 *	unable to find any trajectory that safely reaches the goal), the
		 *	SCIMP controller intervenes and calculates a control that puts the
		 *	system back into a safe state.
		 *
		 *	If you run this file you'll see the velocity profile of a
		 *	user-controlled vehicle as it progresses along the path. At each
		 *	progression, the user-supplied control and the filtered SCIMP
		 *	control are displayed. When they differ, the SCIMP controller
		 *	intervened to take the vehicle out of harm's way.
		 */
		
		// For demonstration, we'll apply this control to the user-vehicle
		// at every time step. This simulates someone commanding the vehicle
		// to go at full acceleration. Following this control blindly would
		// result in collision and violation of the final velocity constraints.
		double user_control = user.getVehicle().getMaximumAcceleration();
		
		// Set up a loop that steps through time up to the pre-defined limit.
		double current_time = 0.;
		double current_velocity = 0.;
		std::cout << "Velocity profile for example trajectory:" << std::endl << std::endl;
		while ( !user.pathTraversed() && !user.timeLimitReached() && (current_time <= time_limit) ) {
			
			// Display current status of the user's vehicle
			std::cout << "Position: " << user.getVehicle().getPosition() << ", time: " << current_time << ", velocity: " << user.getVehicle().getVelocity() << std::endl;
			
			// Attempt to apply user_control over this time step
			double scimp_control = user.applyFilteredControl( user_control, time_step );
			
			// Display user's control and scimp's control
			std::cout << "User control: " << user_control << ", SCIMP control: " << scimp_control << std::endl;
			std::cout << std::endl;
			
			// Step forward in time.
			current_time += time_step;
		}
	
	// if constraint construction failed, the exception is caught here
	} catch ( int e ) {
		Constraints::exceptionMessage( e );
		return -1;
	}
	
	return 0;
}
