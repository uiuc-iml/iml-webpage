/**
 * This code is an example client that communicates with the socket server in
 * order to run a scenario through the planner. It proceeds in five stages:
 *
 * 1. The socket is set up.
 *
 * 2. The scenario XML is sent over the socket to the server.
 *
 * 3. The client writes commands to the socket, which are parse by the server
 *	  and run through the planner and writes the results of the command back to
 *	  the socket for the client.
 *
 * 4. The client interprests the results of the server.
 *
 * 5. Once the scenario is complete, the server returns "DONE" and exits.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sstream>
#include <iostream>
#include <errno.h>
#include <PVTP/SocketInterface.hpp>

// the scenario API, including I/O is contained in the SCIMP_Scenario namespace
using namespace SCIMP_Scenario;

// the namespace of the socket interface
using namespace SocketInterface;

// get sockaddr, IPv4 or IPv6:
void *get_in_addr(struct sockaddr *sa)
{
    if (sa->sa_family == AF_INET) {
        return &(((struct sockaddr_in*)sa)->sin_addr);
    }
	
    return &(((struct sockaddr_in6*)sa)->sin6_addr);
}

int main( int argc, char *argv[] ) {
	
	/**
	 * STEP 1: Set up the socket information
	 * This code connects to the given socket and hostname
	 */
	int portno;
	if ( argc < 3 ) {
		std::cerr << "Usage: " << argv[0] << " HOSTNAME PORT" << std::endl;
		return 1;
	} else {
		portno = atoi( argv[2] );
	}
	
    struct sockaddr_in serv_addr;
    struct hostent *server;
	
    int sockfd = socket( AF_INET, SOCK_STREAM, 0 );
    if (sockfd < 0) {
		std::cerr << "ERROR opening socket" << strerror(errno) << std::endl;
		return 1;
	}
    server = gethostbyname( argv[1] );
    if (server == NULL) {
		std::cerr << "ERROR, no such host: " << argv[1] << std::endl;
        return 1;
    }
	
    bzero( (char *) &serv_addr, sizeof(serv_addr) );
    serv_addr.sin_family = AF_INET;
    bcopy((char *)server->h_addr, 
		  (char *)&serv_addr.sin_addr.s_addr,
		  server->h_length);
    serv_addr.sin_port = htons(portno);
	
    if ( connect( sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr) ) < 0 ) { 
		std::cerr << "ERROR connecting, connect returned: " << strerror(errno) << std::endl;
	}
	
	/**
	 * STEP 2: This codes sends the scenario XML file to the socket, it then
	 * listens to the socket for a response from the socket server. If it
	 * recieves "SUCCESS", then the XML file was recieved and parsed, and the
	 * server is ready to recieve commands.
	 */
	std::string xml_text;
	//std::string path = "data/sample_scenario_configuration.xml";
	std::string path = "data/nik.xml";
	if ( !IO::LoadFileToString(xml_text, path) ) {
		std::cerr << "Error reading the file: " << path << std::endl;
		return 1;
	}
	
	// write the data in chunks to the socket
	int bytes_remaining = xml_text.length() + 1; // c string is null terminated, so add one for the null character
	const char * text = xml_text.c_str();
	int offset = 0;
	while (bytes_remaining > 0) {
		int bytes_written = send( sockfd, &text[offset], bytes_remaining, MSG_WAITALL );
		if (bytes_written < 0) {
			std::cerr << "Error writing to socket, send returned \"" << strerror(errno) << "\"" << std::endl;
			close( sockfd );
			return 1;
		}
		bytes_remaining -= bytes_written;
		offset += bytes_written;
	}
	
	// wait for the return value
	char buffer[64];
	size_t buffer_size = sizeof( buffer );
	std::stringstream tmp;
	tmp.str( "" );
	do {
		bytes_remaining = recv( sockfd, buffer, buffer_size, MSG_DONTWAIT );
		
		if ( bytes_remaining >= 0 ) {
			
			// concatenate buffer to data string
			tmp << buffer;
			
		} else {
			if ( errno == EAGAIN ) {
				bytes_remaining = (int)buffer_size;
				continue;
			}
			std::cerr << "Error reading from socket, recv returned \"" << strerror(errno) << "\"" << std::endl;
			std::cerr << "bytes_read: " << bytes_remaining << ", buffer_size: " << buffer_size << std::endl;
			return false;
		}

	} while ( bytes_remaining >= (int)buffer_size );

	std::cout << "client recieved: " << tmp.str() << std::endl;
	
	/**
	 * STEP 3: Once the scenario has been created on the server side, send
	 * commands to the planner. The commands are formatted as colon-delimited
	 * tuples and sent as strings. The format is:
	 *
	 * [time step]:[current position]:[current velocity]:[target position]:[target velocity]
	 *
	 * So, for instance, this string:
	 *
	 * 0.1:0.0:0.0:1.0:1.0
	 *
	 * would say, 'The time step over which the next control should be executed
	 * is 0.1 seconds. My current position along the path is 0.0 meters. My
	 * current velocity is 0.0 m/s. My desired position along the path is 1.0 m.
	 * My desired velocity at that position is 1.0 m/s.'
	 */
	
	/*
	std::vector<std::string> nik_commands;
	nik_commands.push_back("0.1,0.001,0.008,0.0018,0.008");
	nik_commands.push_back("0.1,0.002,0.006,0.0026,0.006");
	nik_commands.push_back("0.1,0.003,0.007,0.0037,0.007");
	nik_commands.push_back("0.1,0.003,0.007,0.0037,0.007");
	nik_commands.push_back("0.1,0.004,0.007,0.0047,0.007");
	nik_commands.push_back("0.1,0.005,0.009,0.0059,0.009");
	nik_commands.push_back("0.1,0.006,0.012,0.0072,0.012");
	nik_commands.push_back("0.1,0.008,0.011,0.0091,0.011");
	nik_commands.push_back("0.1,0.009,0.011,0.0101,0.011");
	nik_commands.push_back("0.1,0.01,0.01,0.011,0.01");
	nik_commands.push_back("0.1,0.011,0.009,0.0119,0.009");
	nik_commands.push_back("0.1,0.012,0.008,0.0128,0.008");
	nik_commands.push_back("0.1,0.013,0.007,0.0137,0.007");
	nik_commands.push_back("0.1,0.014,0.007,0.0147,0.007");
	nik_commands.push_back("0.1,0.014,0.006,0.0146,0.006");
	nik_commands.push_back("0.1,0.015,0.006,0.0156,0.006");
	nik_commands.push_back("0.1,0.016,0.006,0.0166,0.006");
	nik_commands.push_back("0.1,0.016,0.007,0.0167,0.007");
	nik_commands.push_back("0.1,0.017,0.01,0.018,0.01");
	nik_commands.push_back("0.1,0.018,0.014,0.0194,0.014");
	nik_commands.push_back("0.1,0.02,0.018,0.0218,0.018");
	nik_commands.push_back("0.1,0.022,0.025,0.0245,0.025");
	nik_commands.push_back("0.1,0.025,0.033,0.0283,0.033");
	nik_commands.push_back("0.1,0.029,0.043,0.0333,0.043");
	nik_commands.push_back("0.1,0.034,0.056,0.0396,0.056");
	nik_commands.push_back("0.1,0.04,0.071,0.0471,0.071");
	nik_commands.push_back("0.1,0.048,0.089,0.0569,0.089");
	nik_commands.push_back("0.1,0.058,0.109,0.0689,0.109");
	nik_commands.push_back("0.1,0.07,0.131,0.0831,0.131");
	nik_commands.push_back("0.1,0.084,0.155,0.0995,0.155");
	nik_commands.push_back("0.1,0.101,0.181,0.1191,0.181");
	nik_commands.push_back("0.1,0.121,0.222,0.1432,0.222");
	nik_commands.push_back("0.1,0.147,0.317,0.1787,0.317");
	nik_commands.push_back("0.1,0.185,0.446,0.2296,0.446");
	nik_commands.push_back("0.1,0.236,0.58,0.294,0.58");
	nik_commands.push_back("0.1,0.301,0.718,0.3728,0.718");
	nik_commands.push_back("0.1,0.38,0.857,0.4657,0.857");
	nik_commands.push_back("0.1,0.472,0.997,0.5717,0.997");
	nik_commands.push_back("0.1,0.581,1.19,0.7,1.19");
	nik_commands.push_back("0.1,0.713,1.464,0.8594,1.464");
	nik_commands.push_back("0.1,0.873,1.734,1.0464,1.734");
	nik_commands.push_back("0.1,1.058,1.989,1.2569,1.989");
	nik_commands.push_back("0.1,1.269,2.231,1.4921,2.231");
	nik_commands.push_back("0.1,1.504,2.461,1.7501,2.461");
	nik_commands.push_back("0.1,1.76,2.677,2.0277,2.677");
	nik_commands.push_back("0.1,2.038,2.884,2.3264,2.884");
	nik_commands.push_back("0.1,2.335,3.079,2.6429,3.079");
	nik_commands.push_back("0.1,2.653,3.3,2.983,3.3");
	nik_commands.push_back("0.1,2.996,3.552,3.3512,3.552");
	nik_commands.push_back("0.1,3.362,3.791,3.7411,3.791");
	nik_commands.push_back("0.1,3.752,4.02,4.154,4.02");
	nik_commands.push_back("0.1,4.163,4.237,4.5867,4.237");
	nik_commands.push_back("0.1,4.598,4.446,5.0426,4.446");
	nik_commands.push_back("0.1,5.052,4.646,5.5166,4.646");
	nik_commands.push_back("0.1,5.525,4.838,6.0088,4.838");
	nik_commands.push_back("0.1,6.019,5.06,6.525,5.06");
	nik_commands.push_back("0.1,6.536,5.311,7.0671,5.311");
	nik_commands.push_back("0.1,7.079,5.551,7.6341,5.551");
	nik_commands.push_back("0.1,7.645,5.781,8.2231,5.781");
	nik_commands.push_back("0.1,8.232,6,8.832,6");
	nik_commands.push_back("0.1,8.843,6.214,9.4644,6.214");
	nik_commands.push_back("0.1,9.472,6.422,10.1142,6.422");
	nik_commands.push_back("0.1,10.124,6.627,10.7867,6.627");
	nik_commands.push_back("0.1,10.798,6.847,11.4827,6.847");
	nik_commands.push_back("0.1,11.49,7.051,12.1951,7.051");
	nik_commands.push_back("0.1,12.205,7.24,12.929,7.24");
	nik_commands.push_back("0.1,12.935,7.419,13.6769,7.419");
	nik_commands.push_back("0.1,13.686,7.623,14.4483,7.623");
	nik_commands.push_back("0.1,14.461,7.859,15.2469,7.859");
	nik_commands.push_back("0.1,15.254,8.083,16.0623,8.083");
	nik_commands.push_back("0.1,16.073,8.3,16.903,8.3");
	nik_commands.push_back("0.1,16.911,8.512,17.7622,8.512");
	nik_commands.push_back("0.1,17.772,8.721,18.6441,8.721");
	nik_commands.push_back("0.1,18.651,8.924,19.5434,8.924");
	nik_commands.push_back("0.1,19.554,9.126,20.4666,9.126");
	nik_commands.push_back("0.1,20.476,9.324,21.4084,9.324");
	nik_commands.push_back("0.1,21.414,9.52,22.366,9.52");
	nik_commands.push_back("0.1,22.376,9.713,23.3473,9.713");
	nik_commands.push_back("0.1,23.353,9.904,24.3434,9.904");
	nik_commands.push_back("0.1,24.353,10.092,25.3622,10.092");
	nik_commands.push_back("0.1,25.371,10.282,26.3992,10.282");
	nik_commands.push_back("0.1,26.405,10.472,27.4522,10.472");
	nik_commands.push_back("0.1,27.461,10.658,28.5268,10.658");
	nik_commands.push_back("0.1,28.532,10.837,29.6157,10.837");
	nik_commands.push_back("0.1,29.624,11.015,30.7255,11.015");
	nik_commands.push_back("0.1,30.734,11.191,31.8531,11.191");
	nik_commands.push_back("0.1,31.858,11.367,32.9947,11.367");
	nik_commands.push_back("0.1,33.003,11.546,34.1576,11.546");
	nik_commands.push_back("0.1,34.162,11.722,35.3342,11.722");
	nik_commands.push_back("0.1,35.343,11.897,36.5327,11.897");
	nik_commands.push_back("0.1,36.542,12.074,37.7494,12.074");
	nik_commands.push_back("0.1,37.753,12.251,38.9781,12.251");
	nik_commands.push_back("0.1,38.987,12.427,40.2297,12.427");
	nik_commands.push_back("0.1,40.233,12.602,41.4932,12.602");
	nik_commands.push_back("0.1,41.502,12.778,42.7798,12.778");
	nik_commands.push_back("0.1,42.788,12.955,44.0835,12.955");
	nik_commands.push_back("0.1,44.087,13.13,45.4,13.13");
	nik_commands.push_back("0.1,45.409,13.305,46.7395,13.305");
	nik_commands.push_back("0.1,46.743,13.4,48.0911,13.4");
	nik_commands.push_back("0.1,48.1,13.4,49.4658,13.4");
	nik_commands.push_back("0.1,49.474,13.4,50.8575,13.4");
	nik_commands.push_back("0.1,50.861,13.4,52.2621,13.4");
	nik_commands.push_back("0.1,52.271,13.4,53.6896,13.4");
	nik_commands.push_back("0.1,53.692,13.4,55.1281,13.4");
	nik_commands.push_back("0.1,55.137,13.4,56.5906,13.4");
	nik_commands.push_back("0.1,56.599,13.4,58.0701,13.4");
	nik_commands.push_back("0.1,58.073,13.4,59.5614,13.4");
	nik_commands.push_back("0.1,59.57,13.4,61.0758,13.4");
	nik_commands.push_back("0.1,61.078,13.4,62.6011,13.4");
	nik_commands.push_back("0.1,62.61,13.4,64.1504,13.4");
	nik_commands.push_back("0.1,64.153,13.4,65.7106,13.4");
	nik_commands.push_back("0.1,65.719,13.4,67.2939,13.4");
	nik_commands.push_back("0.1,67.302,13.4,68.8941,13.4");
	nik_commands.push_back("0.1,68.896,13.4,70.5051,13.4");
	nik_commands.push_back("0.1,70.514,13.4,72.1403,13.4");
	nik_commands.push_back("0.1,72.142,13.4,73.7853,13.4");
	nik_commands.push_back("0.1,73.794,13.4,75.4543,13.4");
	nik_commands.push_back("0.1,75.463,13.4,77.1404,13.4");
	nik_commands.push_back("0.1,77.141,13.4,78.8353,13.4");
	nik_commands.push_back("0.1,78.844,13.4,80.5552,13.4");
	nik_commands.push_back("0.1,80.557,13.4,82.2851,13.4");
	nik_commands.push_back("0.1,82.293,13.4,84.038,13.4");
	nik_commands.push_back("0.1,84.047,13.4,85.8088,13.4");
	nik_commands.push_back("0.1,85.809,13.4,87.5875,13.4");
	nik_commands.push_back("0.1,87.596,13.4,89.3913,13.4");
	nik_commands.push_back("0.1,89.393,13.4,91.205,13.4");
	nik_commands.push_back("0.1,91.213,13.4,93.0417,13.4");
	nik_commands.push_back("0.1,93.05,13.4,94.8953,13.4");
	nik_commands.push_back("0.1,94.896,13.4,96.7579,13.4");
	nik_commands.push_back("0.1,96.766,13.4,98.6445,13.4");
	nik_commands.push_back("0.1,98.645,13.4,100.54,13.4");
	nik_commands.push_back("0.1,100.548,13.4,102.46,13.4");
	nik_commands.push_back("0.1,102.468,13.4,104.396,13.4");
	size_t nik_commands_index = 0;
	*/
	
	std::stringstream stopping_cond;
	double path_position = 0.;
	double time_step = 0.1;
	double velocity = 0.;
	do {
		// send tuple of state and control information
		// [time step]:[current position]:[current velocity]:[target position]:[target velocity]
		std::stringstream command_string;
		command_string << time_step << COMMAND_DELIM << path_position << COMMAND_DELIM << velocity << COMMAND_DELIM << (path_position + 0.1) << COMMAND_DELIM << (velocity + 0.1);
		//std::cout << command_string.str() << std::endl;
		//command_string << nik_commands.at( nik_commands_index++ );
		
		// write the data in chunks to the socket
		bytes_remaining = command_string.str().length() + 1; // c string is null terminated, so add one for the null character
		text = command_string.str().c_str();
		offset = 0;
		while (bytes_remaining > 0) {
			int bytes_written = send( sockfd, &text[offset], bytes_remaining, MSG_WAITALL );
			if (bytes_written < 0) {
				std::cerr << "Error writing to socket, send returned \"" << strerror(errno) << "\"" << std::endl;
				close( sockfd );
				return 1;
			}
			bytes_remaining -= bytes_written;
			offset += bytes_written;
		}
		
		/**
		 * STEP 4: The planner parses the command string and attempts to compute a control that
		 * achieves the desired position and velocity at the end of the given
		 * time step while remaining collision-free. It returns this information
		 * in a string formatted as:
		 *
		 * [time step]:[filtered control]:[path position]:[user velocity]
		 *
		 * The client can then parse out this information and do whatever it needs
		 * to with it.
		 */
		stopping_cond.str( "" );
		char return_buffer[64];
		size_t return_buffer_size = sizeof( return_buffer );
		do {
			bytes_remaining = recv( sockfd, return_buffer, return_buffer_size, MSG_DONTWAIT );
			
			if ( bytes_remaining >= 0 ) {
				
				// concatenate buffer to data string
				stopping_cond << return_buffer;
				
			} else {
				if ( errno == EAGAIN ) {
					bytes_remaining = (int)return_buffer_size;
					continue;
				}
				std::cerr << "Error reading from socket, recv returned \"" << strerror(errno) << "\"" << std::endl;
				std::cerr << "bytes_read: " << bytes_remaining << ", return_buffer_size: " << return_buffer_size << std::endl;
				return false;
			}
			
		} while ( bytes_remaining >= (int)return_buffer_size );
		
		// parse out response
		// [time step]:[filtered control]:[path position]:[user velocity]
		std::vector<std::string> pieces;
		Utilities::StringExplode( stopping_cond.str(), COMMAND_DELIM, pieces );
		
		if ( stopping_cond.str().compare("DONE") != 0 ) {
			if ( pieces.size() != 4 ) {
				std::cerr << "Return string improperly formatted: " << stopping_cond.str() << " skipping." << std::endl;
				continue;
			}
			
			double time_step = atof( pieces[0].c_str() );
			double scimp_control = atof( pieces[1].c_str() );
			path_position = atof( pieces[2].c_str() );
			velocity = atof( pieces[3].c_str() );
			
			std::cout << "control: " << scimp_control << ", position: " << path_position << ", velocity: " << velocity << std::endl;
		}
		
	/**
	 * STEP 5: Finally, when the scenario is complete, the planner will return "DONE"
	 * instead of the return string above.
	 */
	} while ( stopping_cond.str().compare("DONE") != 0 );
	
	std::cout << "stopping condition: " << stopping_cond.str() << std::endl;
	
    close( sockfd );
	
    return 0;
}
