/**
 * EXAMPLE SCENARIO CREATION AND EVALUATION WITH XML INPUT
 *
 * This file demonstrates setting up a simple lane-crossing scenario using XML
 * to specify the configuration of the vehicles, and evaluating that scenario to
 * construct path-time obstacles that can be fed into the planner.
 *
 * LIMITATIONS: The API currently only supports scenarios in which
 * the user-controlled vehicle follows a straight-line path, and obstacle
 * vehicles follow straight-line paths that cross the user-controlled vehicle's
 * path perpendicularly; so, scenarios that have the driver driving straight
 * across lanes of traffic. I am working on extending the scenario to handle
 * elliptical as well as linear paths, and arbitrary angles of intersection.
 *
 * SETUP: A scenario consists of a user-controlled vehicle, and a (possibly
 * empty) set of obstacles (other vehicles). These two things are described by
 * the ScenarioUser and ScenarioObstacle classes, respectively.
 *
 * The ScenarioUser class consists of a Vehicle object and a Path object, which
 * respectively describe the characteristics of the user's vehicle (such as
 * length, width, velocity, position, etc.), and the path that the vehicle
 * follows. Because this is the user-controlled vehicle, it also contains
 * a representation of the scenario (the other vehicles and their paths), and
 * and a SCIMP controller which attempts to prevent the user from executing
 * unsafe controls.
 *
 * The ScenarioObstacle class also contains a Vehicle and a Path. Instead of
 * a SCIMP controller, it contains an actual controller that defines how the
 * vehicle is controlled over time. (In this context, control is limited to
 * longitudinal control: acceleration or deceleration.)
 */

#include <iostream>
#include <PVTP/Planner.hpp>
#include <PVTP/ScenarioUser.hpp>
#include <PVTP/Utilities.hpp>
#include <PVTP/ScenarioReader.hpp>

// the planner is contained in the PVTP namespace
using namespace PVTP;

// the scenario API, including I/O is contained in the SCIMP_Scenario namespace
using namespace SCIMP_Scenario;

int main( int argc, char *argv[] ) {
	
	/**
	 *	This first section just handles input parameters and loading the
	 *	data file.
	 */

	// I use this for reading out values with enough precision to do debugging;
	// sometimes it's handy to print something out to cerr to see what's
	// going on
	std::cerr.precision(Constants::DEBUGGING_OUTPUT_PRECISION);
	
	// storage for the data file path
	std::string path;
	
	// read input parameters...
	if ( argc < 2 ) {
		
		// ...if no file is specified, use this path as default
		path.assign( "data/sample_scenario_configuration.xml" );
		
	} else if ( argc == 2 ) {
		
		// ...otherwise, assume the first argument is the path
		path.assign( argv[1] );
		
	} else {
		
		// ...if any more arguments are specified, error out
		std::string name( &argv[0][2] );
		std::cout << "usage: " << name << std::endl;
		std::cout << "       " << name << " input_file" << std::endl;
		return 1;
		
	}

	// storage for the scenario
	ScenarioUser * user = NULL;

	// attempt to load the scenario from 'path' into 'user'
	if ( !IO::ReadScenarioFromXML(user, path) ) {
		std::cerr << "Scenario creation from input file '" << path << "' failed." << std::endl;
		return 1;
	}
	
	/**
	 *	At this point, the scenario is constructed. Scenario evaluation
	 *	takes the provided scenario and computes path-time obstacles used
	 *	by the planner to evaluate the safety of a given state. We can
	 *	take a look at this information.
	 *
	 *	The ScenarioUser object maintains an internal set of path-time
	 *	obstacles, but we can manually compute the set here and print
	 *	out the results.
	 *
	 *	With the default inputs specified in this file, you should see as
	 *	output:
	 *
	 *		Path-time obstacle set size: 1
	 *		Obstacle:
	 *		(12.75, 3.35, [-Inf, +Inf])
	 *		(21.75, 3.35, (empty))
	 *		(21.75, 1.55, [-Inf, +Inf])
	 *		(12.75, 1.55, (empty))
	 *
	 *	Each line under "Obstacle:" corresponds to an obstacle vertex, where
	 *	the first number is the path coordinate, and the second number is
	 *	the time coordinate. The third member is the set of velocities that
	 *	are geometrically feasible at that point. The two empty sets
	 *	correspond to the lower-left and upper-right vertices of the
	 *	obstacle in path-time space: the upper-right point is unreachable
	 *	without colliding with the obstacle, and the lower-left is
	 *	reachable, but collision is inevitable upon reaching it. Time is
	 *	assumed to be monotonically increasing.
	 *
	 */
	
	std::cout << std::endl << "===OUTPUT FROM EXAMPLE SCENARIO===" << std::endl;
	std::cout << std::endl;
	
	// Construct set for storing path-time obstacles.
	PVT_ObstacleSet pt_obstacles;
	
	// Manually compute path-time obstacles.
	if ( user->getScenario().computePathTimeObstacles( pt_obstacles, user->getConstraints() ) ) {
		std::cout << "Initial set of path-time obstacles, set size: " << pt_obstacles.obstacles->size() << std::endl;
		std::cout << pt_obstacles << std::endl;
		std::cout << std::endl;
	} else {
		std::cout << "Path-time obstacle construction failed." << std::endl;
		std::cout << std::endl;
	}
	
	/**
	 *	Now we can test executing a scenario. The obstacle vehicle will
	 *	proceed along its path according to the initial velocity and given
	 *	control (in this case 5 m/s and 0 m/s^2, respectively). We'll set
	 *	the user control to be 8 m/s^2 at every time step. Applied blindly,
	 *	this control would result in collision, so, at every time step, the
	 *	current state of the system is evaluated by taking the user's
	 *	and computing the state of the system one time step in advance. If
	 *	that future state is deemed unsafe (which means the planner was
	 *	unable to find any trajectory that safely reaches the goal), the
	 *	SCIMP controller intervenes and calculates a control that puts the
	 *	system back into a safe state.
	 *
	 *	If you run this file you'll see the velocity profile of a
	 *	user-controlled vehicle as it progresses along the path. At each
	 *	progression, the user-supplied control and the filtered SCIMP
	 *	control are displayed. When they differ, the SCIMP controller
	 *	intervened to take the vehicle out of harm's way.
	 */
	
	// First define a time step at which to run the scenario.
	double time_step = user->getTimeStep();
	
	// For demonstration, we'll apply this control to the user-vehicle
	// at every time step. This simulates someone commanding the vehicle
	// to go at full acceleration. Following this control blindly would
	// result in collision and violation of the final velocity constraints.
	double user_control = user->getVehicle().getMaximumAcceleration();
	
	// Set up a loop that steps through time up to the pre-defined limit.
	double current_time = 0.;
	double current_velocity = 0.;
	std::cout << "Velocity profile for example trajectory:" << std::endl << std::endl;
	while ( !user->pathTraversed() && !user->timeLimitReached() && (current_time <= user->getConstraints().getTLimit()) ) {
		
		// Display current status of the user's vehicle
		std::cout << "Position: " << user->getVehicle().getPosition() << ", time: " << current_time << ", velocity: " << user->getVehicle().getVelocity() << std::endl;
		
		// Attempt to apply user_control over this time step
		double scimp_control = user->applyFilteredControl( user_control, time_step );
		
		// Display user's control and scimp's control
		std::cout << "User control: " << user_control << ", SCIMP control: " << scimp_control << std::endl;
		std::cout << std::endl;
		
		// Step forward in time.
		current_time += time_step;
	}
	
	return 0;
}
