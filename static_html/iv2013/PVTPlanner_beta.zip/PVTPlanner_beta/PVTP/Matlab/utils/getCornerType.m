function [ type ] = getCornerType( p )
%getCornerType Summary of this function goes here
%   Detailed explanation goes here

    type = p(1, 3);

end

